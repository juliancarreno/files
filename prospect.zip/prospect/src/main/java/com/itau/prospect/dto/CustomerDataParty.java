package com.itau.prospect.dto;


import com.google.gson.annotations.SerializedName;

public class CustomerDataParty {
	private Object PartyKey;
	private Object PartyStatus;
	private Object PersonPartyInfo;
	@SerializedName("PartyAdditionalInfoList")
	private CustomerDataPartitionAdditionInfoList PartyAdditionalInfoList;
	
	public Object getPartyKey() {
		return PartyKey;
	}
	public void setPartyKey(Object partyKey) {
		PartyKey = partyKey;
	}
	public Object getPartyStatus() {
		return PartyStatus;
	}
	public void setPartyStatus(Object partyStatus) {
		PartyStatus = partyStatus;
	}
	public Object getPersonPartyInfo() {
		return PersonPartyInfo;
	}
	public void setPersonPartyInfo(Object personPartyInfo) {
		PersonPartyInfo = personPartyInfo;
	}
	public CustomerDataPartitionAdditionInfoList getPartyAdditionalInfoList() {
		return PartyAdditionalInfoList;
	}
	public void setPartyAdditionalInfoList(CustomerDataPartitionAdditionInfoList partyAdditionalInfoList) {
		PartyAdditionalInfoList = partyAdditionalInfoList;
	}
	
	



}
