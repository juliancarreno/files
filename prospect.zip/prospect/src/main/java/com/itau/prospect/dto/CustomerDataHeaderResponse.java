package com.itau.prospect.dto;

import java.util.List;

public class CustomerDataHeaderResponse {
	private List<?> MessageHeader;
	private List<?> Status;
	
	
	public List<?> getMessageHeader() {
		return MessageHeader;
	}
	public void setMessageHeader(List<?> messageHeader) {
		MessageHeader = messageHeader;
	}
	public List<?> getStatus() {
		return Status;
	}
	public void setStatus(List<?> status) {
		Status = status;
	}
	
	
	
	

	
	
}
