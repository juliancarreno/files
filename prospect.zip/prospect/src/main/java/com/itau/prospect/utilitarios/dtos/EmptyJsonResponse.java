package com.itau.prospect.utilitarios.dtos;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class EmptyJsonResponse {

}
