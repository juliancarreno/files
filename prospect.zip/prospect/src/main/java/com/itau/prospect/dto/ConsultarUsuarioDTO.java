package com.itau.prospect.dto;

import com.google.gson.annotations.SerializedName;

public class ConsultarUsuarioDTO {
	
	//los dos primeros no son necesarios
	@SerializedName("OperacionExitosa")
	private String OperacionExitosa;
	@SerializedName("Usuario")
	private ConsultarUsuarioUsuarioDTO Usuario;
	
	
	public String getOperacionExitosa() {
		return OperacionExitosa;
	}
	public void setOperacionExitosa(String operacionExitosa) {
		OperacionExitosa = operacionExitosa;
	}
	public ConsultarUsuarioUsuarioDTO getUsuario() {
		return Usuario;
	}
	public void setUsuario(ConsultarUsuarioUsuarioDTO usuario) {
		Usuario = usuario;
	}



}
