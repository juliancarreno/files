package com.itau.prospect.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itau.prospect.utilitarios.excep.CustomRuntimeException;
@Service
public class ProspectService {
	Logger logger = LoggerFactory.getLogger(ProspectServiceImpl.class);// Manejo de errores
	@Autowired
	ProspectServiceImpl prospectServiceImpl;
	
	public String identificacionCliente(String prospect_id) {
		String[] vectProspect = prospect_id.split("_");
		try {
			int codigoCedula = 0;
			switch (vectProspect[2]) {
			case "CC":
				codigoCedula = 1;
				break;
			case "CE":
				codigoCedula = 2;
				break;
			case "RC":
				codigoCedula = 3;
				break;
			case "TI":
				codigoCedula = 4;
				break;
			case "PA":
				codigoCedula = 5;
				break;

			default:
				throw new CustomRuntimeException("400_No se encontro el tipo de cedula");
			}
			// Extracciones de datos
			String customerStatus = prospectServiceImpl.getCustomerStatus(codigoCedula, vectProspect[0]);
			String customerData =   prospectServiceImpl.getCustomerStatus(codigoCedula, vectProspect[0]);
			String listConsulta =   prospectServiceImpl.getListConsulta(codigoCedula, vectProspect[0]);

			return "200_Cliente aprobado";
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());

		}
	}

}
