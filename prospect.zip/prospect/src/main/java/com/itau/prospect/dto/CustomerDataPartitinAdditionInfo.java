package com.itau.prospect.dto;

public class CustomerDataPartitinAdditionInfo {

	private String additionalInfoId;
	private String additionalInfoName;
	private String additionalInfoValue;
	private String additionalInfoGroup;
	private String additionalInfoValueType;
	private String requiredInd;
	private String editableInd;
	
	
	
	public String getAdditionalInfoId() {
		return additionalInfoId;
	}
	public void setAdditionalInfoId(String additionalInfoId) {
		this.additionalInfoId = additionalInfoId;
	}
	public String getAdditionalInfoName() {
		return additionalInfoName;
	}
	public void setAdditionalInfoName(String additionalInfoName) {
		this.additionalInfoName = additionalInfoName;
	}
	public String getAdditionalInfoValue() {
		return additionalInfoValue;
	}
	public void setAdditionalInfoValue(String additionalInfoValue) {
		this.additionalInfoValue = additionalInfoValue;
	}
	public String getAdditionalInfoGroup() {
		return additionalInfoGroup;
	}
	public void setAdditionalInfoGroup(String additionalInfoGroup) {
		this.additionalInfoGroup = additionalInfoGroup;
	}
	public String getAdditionalInfoValueType() {
		return additionalInfoValueType;
	}
	public void setAdditionalInfoValueType(String additionalInfoValueType) {
		this.additionalInfoValueType = additionalInfoValueType;
	}
	public String getRequiredInd() {
		return requiredInd;
	}
	public void setRequiredInd(String requiredInd) {
		this.requiredInd = requiredInd;
	}
	public String getEditableInd() {
		return editableInd;
	}
	public void setEditableInd(String editableInd) {
		this.editableInd = editableInd;
	}

}
