package com.itau.prospect.dto;



public class CustomerStatusDTO {

	private CustomerStatusStatus Status;
	private  CustomerStatusPartyStatus PartyStatus;
	
	
	public CustomerStatusStatus getStatus() {
		return Status;
	}
	public void setStatus(CustomerStatusStatus status) {
		Status = status;
	}
	public CustomerStatusPartyStatus getPartyStatus() {
		return PartyStatus;
	}
	public void setPartyStatus(CustomerStatusPartyStatus partyStatus) {
		PartyStatus = partyStatus;
	}
	

	


}
