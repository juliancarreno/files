package com.itau.prospect.dto;

public class ConsultarClienteAniDTO {
	
	private String OperacionExitosa;
	private String ANIInfo;

	

}
