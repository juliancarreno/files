package com.itau.prospect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProspectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProspectApplication.class, args);
	}

}
