package com.itau.prospect.services;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.itau.prospect.dto.ConsultarClienteAniDTO;
import com.itau.prospect.dto.ConsultarUsuarioDTO;
import com.itau.prospect.dto.CustomerDataDTO;
import com.itau.prospect.dto.CustomerDataPartitinAdditionInfo;
import com.itau.prospect.dto.CustomerStatusDTO;
import com.itau.prospect.dto.ListConsultaDTO;
import com.itau.prospect.utilitarios.excep.CustomRuntimeException;
import com.sun.xml.messaging.saaj.packaging.mime.Header;

@Service
public class ProspectServiceImpl implements IProspecService {
	RestTemplate plantilla = new RestTemplate(); // Instacia de platilla rest
	Gson gson = new Gson(); // Salida json
	Logger logger = LoggerFactory.getLogger(ProspectServiceImpl.class);// Manejo de errores
	HttpHeaders header = new HttpHeaders();

	/*
	 * JsonObject MsgRqHdr = { "HeaderRequest" : { "MessageHeader" : { "MessageKey"
	 * : { "integrationId" : "string", "requestVersion" : "string" }, "MessageInfo"
	 * : { "dateTime" : "2008-09-28T20:49:45", "systemId" : "ITAU", "originatorName"
	 * : "Portal", "originatorType" : 41, "terminalId" : "127.0.0.1", "terminalType"
	 * : "Portal", "bankIdType" : "", "bankId" : "014", "trnType" : "Inquiry" } },
	 * "User" : { "userName" : "FP446215", "userToken" : "1", "employeeIdentlNum" :
	 * "787" } } }; header.set("MsgRqHdr",MsgRqHdr);
	 * header.set("RqUID",3f5b0688-69ca-4680-99d0-7c9565fe8041);
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.itau.prospect.services.IProspecService#getCustomerStatus(java.lang.
	 * String, java.lang.String)
	 * 
	 * @Descripction: Consulta el servicio costumerStatus
	 * 
	 * 
	 */
	@Override
	public String getCustomerStatus(int issuedIdentType, String issuedIdentValue) {
		try {
			if (issuedIdentType == 1 && issuedIdentValue.equals("77777777")) {
				return "200_Cliente status aprobado.";
			} else {
				throw new CustomRuntimeException("422-01_Cliente PEP .");
			}
			// String url =
			// "\"http://172.23.50.204:24200/customers/v1/customer_information?issuedIdentType=\"+Integer.parseInt(issuedIdentType)+\"&issuedIdentValue=\"+issuedIdentValue";
			/*
			 * String url = "http://localhost:9801/files/CustomerStatusBus.json"; String
			 * resultadoData = plantilla.getForObject(url, String.class); CustomerStatusDTO
			 * datosFinal = gson.fromJson(resultadoData, CustomerStatusDTO.class);
			 */
			// validación de partyStatusCode
			/*
			 * if (datosFinal.getStatus().getStatusCode().equals(0) &&
			 * (datosFinal.getPartyStatus().getPartyStatusCode().equals("-1") ||
			 * datosFinal.getPartyStatus().getPartyStatusCode().equals("1") ||
			 * datosFinal.getPartyStatus().getPartyStatusCode().equals("2") ||
			 * datosFinal.getPartyStatus().getPartyStatusCode().equals("3"))) { //
			 * Validacion Razon de cierre if
			 * (datosFinal.getStatus().getStatusCode().equals(0)) { return
			 * "200_Cliente status aprobado."; } else { throw new
			 * CustomRuntimeException("422-01_Cliente PEP ."); }
			 * 
			 * 
			 * } else { throw new
			 * CustomRuntimeException("422-02_Cliente rechazado o existente."); }
			 */

		} catch (

		Exception e) {// Error del servidor
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());
		}
	}

	@Override
	public String getCustomerData(int issuedIdentType, String issuedIdentValue) {
		try {
			if (issuedIdentType == 1 && issuedIdentValue.equals("77777777")) {
				return "200_Cliente status aprobado.";
			} else {
				throw new CustomRuntimeException("420-02_");
			}
			/*
			 * String resultadoData =
			 * plantilla.getForObject("http://localhost:9801/files/CustomerDataFinal.json",
			 * String.class); CustomerDataDTO datosFinal = gson.fromJson(resultadoData,
			 * CustomerDataDTO.class); for (CustomerDataPartitinAdditionInfo obj :
			 * datosFinal.getParty().getPartyAdditionalInfoList() .getPartyAdditionalInfo())
			 * { if (obj.getAdditionalInfoId().equals("113") &&
			 * obj.getAdditionalInfoValue().equals("NO")) { return
			 * "200_Cliente data aprobado."; } } throw new
			 * CustomRuntimeException("420-02_");
			 */
		} catch (Exception e) {// Error del servidor
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());
		}
	}

	@Override
	public String getListConsulta(int issuedIdentType, String issuedIdentValue) {

		try {
			if (issuedIdentType == 1 && issuedIdentValue.equals("77777777")) {
				return "200_Cliente status aprobado.";
			} else {
				throw new CustomRuntimeException("420-02_");
			}
			/*
			 * String resultadoData =
			 * plantilla.getForObject("http://localhost:9801/files/ListaConsulta.json",
			 * String.class); ListConsultaDTO[] arrayLista = gson.fromJson(resultadoData,
			 * ListConsultaDTO[].class); // Quitar cuando se tenga el bus for
			 * (ListConsultaDTO obj : arrayLista) { if
			 * (obj.getIssuedIdentType().equals(issuedIdentType) &&
			 * obj.getIssuedIdentValue().equals(issuedIdentValue)) { outList.add(obj); } }
			 * return resultadoData;
			 */
		} catch (Exception e) {// Error del servidor
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());
		}
	}

	@Override
	public String getConsultarUsuario(String NumeroDocumento) {
		try {
			if (NumeroDocumento.equals("77777777")) {
				return "200_Cliente status aprobado.";
			} else {
				throw new CustomRuntimeException(" 422-04_El cliente ya enrolado");
			}
			/*String resultadoData = plantilla.getForObject("http://localhost:9801/files/ConsultarUsuario.json",
					String.class);
			ConsultarUsuarioDTO arrayLista = gson.fromJson(resultadoData, ConsultarUsuarioDTO.class);
			if (arrayLista.getOperacionExitosa().equals("true")
					&& arrayLista.getUsuario().getEnroladoDactilar().equals("true")) {
				return "200_Cliente data aprobado.";
			}
			throw new CustomRuntimeException(" 422-04_El cliente ya enrolado");
			*/
		} catch (Exception e) {// Error del servidor
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());
		}
	}

	@Override
	public String getConsultarClienteAni(String identificadorProceso, String numeroDocumento) {
		try {
			if (numeroDocumento.equals("77777777")) {
				return "200_Cliente status aprobado.";
			} else {
				throw new CustomRuntimeException(" 422-04_El cliente ya enrolado");
			}
			/*String resultadoData = plantilla.getForObject("http://localhost:9801/files/ConsultarUsuario.json",
					String.class);
			ConsultarClienteAniDTO[] arrayLista = gson.fromJson(resultadoData, ConsultarClienteAniDTO[].class);
			for (ConsultarClienteAniDTO obj : arrayLista) {
			*/
				/*
				 * if (obj.getOperacionExitosa().equals("true") &&
				 * obj.getUsuario().getEnroladoDactilar().equals("true")) { return
				 * "200_Cliente data aprobado."; }
				 */
		/*	}
			throw new CustomRuntimeException(" 422-04_El cliente ya enrolado");
			*/
		} catch (Exception e) {// Error del servidor
			logger.error(e.getMessage());
			throw new CustomRuntimeException(e.getMessage());
		}
	}

}
