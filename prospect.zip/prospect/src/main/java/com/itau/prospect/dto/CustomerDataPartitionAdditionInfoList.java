package com.itau.prospect.dto;

import java.util.List;

public class CustomerDataPartitionAdditionInfoList {

	  private List<CustomerDataPartitinAdditionInfo> PartyAdditionalInfo;

	public List<CustomerDataPartitinAdditionInfo> getPartyAdditionalInfo() {
		return PartyAdditionalInfo;
	}

	public void setPartyAdditionalInfo(List<CustomerDataPartitinAdditionInfo> partyAdditionalInfo) {
		PartyAdditionalInfo = partyAdditionalInfo;
	}
	  
	  
}
