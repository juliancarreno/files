package com.itau.prospect.controllers;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.itau.prospect.services.ProspectService;
import com.itau.prospect.services.ProspectServiceImpl;

@CrossOrigin("*")
@RestController
@RequestMapping("/api")
public class ProspectController {
	Logger logger = LoggerFactory.getLogger(ProspectController.class);
	Map<String, Object> respuesta = new HashMap<>();
	String[] mensajes = null;

	@Autowired
	ProspectServiceImpl prospecServiceImpl;
	@Autowired
	ProspectService prospecService;

	// Parametro de entrada 80149333_CO_CC
	@GetMapping("/proceso/{prospect_id}")
	public ResponseEntity<?> procesoIdentificarCliente(@PathVariable String prospect_id) {
		try {
			String outData = prospecService.identificacionCliente(prospect_id);
			mensajes = outData.split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		} catch (Exception e) {
			mensajes = e.getMessage().split("_");
			respuesta.put("mensaje", e.getMessage());
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/constumerStatus/{issuedIdentType}/{issuedIdentValue}")
	public ResponseEntity<?> customerStatus(@PathVariable int issuedIdentType,
			@PathVariable String issuedIdentValue) {
		try {
			String outData = prospecServiceImpl.getCustomerStatus(issuedIdentType, issuedIdentValue);
			mensajes = outData.split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		} catch (Exception e) {
			mensajes = e.getMessage().split("_");
			respuesta.put("mensaje", e.getMessage());
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/constumerData/{issuedIdentType}/{issuedIdentValue}")
	public ResponseEntity<?> customerData(@PathVariable int issuedIdentType, @PathVariable String issuedIdentValue) {
		try {
			String outData = prospecServiceImpl.getCustomerData(issuedIdentType, issuedIdentValue);
			mensajes = outData.split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		} catch (Exception e) {
			mensajes = e.getMessage().split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/lista/{issuedIdentType}/{issuedIdentValue}")
	public String getList(@PathVariable int issuedIdentType, @PathVariable String issuedIdentValue) {
		String outData = prospecServiceImpl.getListConsulta(issuedIdentType, issuedIdentValue);
		return outData;

	}

	@GetMapping("/consultaUsuario/{NumeroDocumento}")
	public ResponseEntity<?> consultarUsuario(@PathVariable String NumeroDocumento) {
		try {
			String outData = prospecServiceImpl.getConsultarUsuario(NumeroDocumento);
			mensajes = outData.split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		} catch (Exception e) {
			mensajes = e.getMessage().split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping("/Any/{IdentificadorProceso}/{NumeroDocumento}")
	public ResponseEntity<?> consultarClienteAni(@PathVariable String IdentificadorProceso,
			@PathVariable String NumeroDocumento) {
		try {
			String outData = prospecServiceImpl.getConsultarClienteAni(IdentificadorProceso, NumeroDocumento);
			mensajes = outData.split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		} catch (Exception e) {
			mensajes = e.getMessage().split("_");
			respuesta.put("mensaje", mensajes[1]);
			respuesta.put("code", mensajes[0]);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}

	}

}
