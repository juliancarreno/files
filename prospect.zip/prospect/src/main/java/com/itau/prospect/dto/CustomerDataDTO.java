package com.itau.prospect.dto;
import com.google.gson.annotations.SerializedName;
public class CustomerDataDTO {
	@SerializedName("Party")
	private CustomerDataParty Party;
	

	public CustomerDataParty getParty() {
		return Party;
	}
	public void setParty(CustomerDataParty party) {
		Party = party;
	}
	

}
