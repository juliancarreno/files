package com.itau.prospect.dto;

public class ProspectDTO {
	
	private String prospect_id;

	public String getProspect_id() {
		return prospect_id;
	}

	public void setProspect_id(String prospect_id) {
		this.prospect_id = prospect_id;
	}

}
