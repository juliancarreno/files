package com.itau.prospect.dto;

public class ListConsultaDTO {
	

	private Integer additionalInfoId;
	private char additionalInfoValue;
	private String issuedIdentValue;
    private String issuedIdentType;
	
	
	public Integer getAdditionalInfoId() {
		return additionalInfoId;
	}
	public void setAdditionalInfoId(Integer additionalInfoId) {
		this.additionalInfoId = additionalInfoId;
	}
	public char getAdditionalInfoValue() {
		return additionalInfoValue;
	}
	public void setAdditionalInfoValue(char additionalInfoValue) {
		this.additionalInfoValue = additionalInfoValue;
	}
	
	public String getIssuedIdentValue() {
		return issuedIdentValue;
	}
	public void setIssuedIdentValue(String issuedIdentValue) {
		this.issuedIdentValue = issuedIdentValue;
	}
	public String getIssuedIdentType() {
		return issuedIdentType;
	}
	public void setIssuedIdentType(String issuedIdentType) {
		this.issuedIdentType = issuedIdentType;
	}
	
	
	

}
