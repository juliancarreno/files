package com.itau.prospect.dto;

public class CustomerStatusStatus {
	
	private Integer statusCode;

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}




}
