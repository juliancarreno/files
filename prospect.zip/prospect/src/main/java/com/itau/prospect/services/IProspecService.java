package com.itau.prospect.services;


public interface IProspecService {
	
	public String getCustomerData(int issuedIdentType, String issuedIdentValue);
	
	public String  getCustomerStatus(int issuedIdentType, String issuedIdentValue);

	public String getListConsulta(int issuedIdentType, String issuedIdentValue);

	public String getConsultarUsuario(String NumeroDocumento);

	public String getConsultarClienteAni(String IdentificadorProceso, String NumeroDocumento );

}
